export { Switch } from './switch'
export type { SwitchProps } from './switch'