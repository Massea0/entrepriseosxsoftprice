export { Typography, typographyVariants } from './typography'
export type { TypographyProps } from './typography'