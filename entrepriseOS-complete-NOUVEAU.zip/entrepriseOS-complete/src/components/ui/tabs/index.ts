export {
  Tabs,
  TabsList,
  TabsTrigger,
  TabsContent,
  TabsBadge,
  TabsIcon,
} from './tabs'

export type {
  TabsListProps,
  TabsTriggerProps,
} from './tabs'